#include <bit/stdc++.h>
using namespace std;
int main()
{
cout<<"hello wolrd"';
}